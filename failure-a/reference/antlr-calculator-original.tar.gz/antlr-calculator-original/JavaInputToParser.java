package one.two.three;

public class M {
    int i;
    public String str;

    public void m();
    private String n();
    private String o();
}
