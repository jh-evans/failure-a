package org.lock;

import org.antlr.v4.runtime.tree.ParseTree;

public interface Walker {
    public void walk(ParseTree t);
}