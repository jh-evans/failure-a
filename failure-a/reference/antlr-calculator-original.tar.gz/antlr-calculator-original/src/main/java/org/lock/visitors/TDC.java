package org.lock.visitors;

import org.antlr.v4.runtime.tree.ParseTree;
import org.lock.TheClass;
import org.lock.antlr4.JavaParser;
import org.lock.antlr4.JavaParser.ClassBodyDeclarationContext;
import org.lock.utils.PList;

public class TDC extends TheVisitor {
    public Class<?> target() {
        return JavaParser.TypeDeclarationContext.class;
    }
    
    public void visit(ParseTree t, TheClass output) {
        JavaParser.TypeDeclarationContext cuc = (JavaParser.TypeDeclarationContext) t;

        PList<JavaParser.IdentifierContext> decls = find(t, org.lock.antlr4.JavaParser.IdentifierContext.class);

        output.setClassname(decls.get(0).getText());
    }
}
