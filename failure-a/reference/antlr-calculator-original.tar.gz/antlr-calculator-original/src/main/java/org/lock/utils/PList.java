package org.lock.utils;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public interface PList<T> extends List<T> {
    public PList<T> comp(Predicate<T> predicate);
    public <R> PList<R> elem(Function<? super T,? extends R> mapper);
}