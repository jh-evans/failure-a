package org.lock.utils;

import java.util.ArrayList;
import java.util.function.Function;
import java.util.function.Predicate;

public class PArrayList<T> extends ArrayList<T> implements PList<T> {
    /**
     * 
     */
    private static final long serialVersionUID = -1621715176385225414L;

    public PList<T> comp(Predicate<T> predicate) {
        PArrayList<T> result = new PArrayList<T>();
        result.addAll(this.stream().filter(predicate).toList());
        return result;
    }
    public <R> PList<R> elem(Function<? super T,? extends R> mapper) {
        PArrayList<R> result = new PArrayList<R>();
        result.addAll(this.stream().map(mapper).toList());
        return result;
    }
}