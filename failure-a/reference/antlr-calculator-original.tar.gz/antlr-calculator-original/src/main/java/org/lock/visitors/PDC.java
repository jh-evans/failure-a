package org.lock.visitors;

import org.antlr.v4.runtime.tree.ParseTree;
import org.lock.TheClass;
import org.lock.antlr4.JavaParser;
import org.lock.antlr4.JavaParser.ClassBodyDeclarationContext;
import org.lock.utils.PList;

public class PDC extends TheVisitor {
    public Class<?> target() {
        return JavaParser.PackageDeclarationContext.class;
    }
    
    public void visit(ParseTree t, TheClass output) {
        JavaParser.PackageDeclarationContext cuc = (JavaParser.PackageDeclarationContext) t;

        PList<JavaParser.QualifiedNameContext> decls = find(t, JavaParser.QualifiedNameContext.class);

        String packagename = "";
        for(ParseTree n : decls.get(0).children) {
            packagename += n.getText();      
        }
        
        output.setPackagename(packagename);
    }
}
