package org.lock.visitors;

import org.antlr.v4.runtime.tree.ParseTree;
import org.lock.TheClass;

public interface Visit {
    public Class<?> target();
    public void visit(ParseTree t, TheClass output);
}
