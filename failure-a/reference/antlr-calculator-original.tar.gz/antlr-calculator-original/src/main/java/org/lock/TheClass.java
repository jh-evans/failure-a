package org.lock;

import java.util.List;

import org.lock.utils.PArrayList;

public class TheClass {
    public String packagename;
    public String classname;
    List<String> pub;
    
    public void setPackagename(String packagename) {
        this.packagename = packagename;
        this.pub = new PArrayList<String>();
    }
    
    public void setClassname(String classname) {
        this.classname = classname;
    }
    
    public void addPublic(String pub) {
        this.pub.add(pub);
    }
    
    public String toString() {
        String result = "";
        for(String e : pub) {
            result += "    " + e + "\n";
        }
        
        return "packagename <" + packagename + ">" + "\n" +
               "classname <" + classname + ">" + "\n" +
               "public elems" + "\n" +
               result;
               
    }
}