package org.lock.visitors;

import org.antlr.v4.runtime.tree.ParseTree;
import org.lock.TheClass;
import org.lock.antlr4.JavaParser;
import org.lock.antlr4.JavaParser.ClassBodyDeclarationContext;
import org.lock.utils.PList;

public class CUC extends TheVisitor {
    public Class<?> target() {
        return JavaParser.CompilationUnitContext.class;
    }
    
    public void visit(ParseTree t, TheClass output) {
        JavaParser.CompilationUnitContext cuc = (JavaParser.CompilationUnitContext) t;
        System.out.println(cuc.getText());
    }
}