package org.lock;

import java.util.HashMap;
import java.util.Map;

import org.antlr.v4.runtime.tree.ParseTree;
import org.lock.antlr4.JavaParser;
import org.lock.visitors.CBC;
import org.lock.visitors.CUC;
import org.lock.visitors.PDC;
import org.lock.visitors.QNC;
import org.lock.visitors.TDC;
import org.lock.visitors.Visit;

public class TypeChecker {
    private TheClass output;
    private Map<Class<?>, Visit> visitors;
    
    public TypeChecker(TheClass output) {
        this.output = output;
        
        visitors = new HashMap<Class<?>, Visit>();
        visitors.put(JavaParser.ClassBodyContext.class, new CBC());
        visitors.put(JavaParser.TypeDeclarationContext.class, new TDC());
        visitors.put(JavaParser.PackageDeclarationContext.class, new PDC());

        for(Map.Entry<Class<?>, Visit> entry : visitors.entrySet()) {
            if(!entry.getKey().equals(entry.getValue().target())) {
                assert false;
            }
        }
    }

    public void walk(ParseTree t) {
        if(visitors.containsKey(t.getClass())) {
            visitors.get(t.getClass()).visit(t, output);
        }

        int n = t.getChildCount();
        for (int j = 0; j<n; j++) {
            walk(t.getChild(j));
        }
    }
}