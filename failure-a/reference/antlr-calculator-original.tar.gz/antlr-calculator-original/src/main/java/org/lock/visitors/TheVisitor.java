package org.lock.visitors;

import org.antlr.v4.runtime.tree.ParseTree;
import org.lock.utils.PArrayList;
import org.lock.utils.PList;

public abstract class TheVisitor implements Visit {    
    protected <T> PList<T> find(ParseTree t, Class<?> node_type) {
        return find(t, node_type, new PArrayList<T>());

    }

    protected <T> PList<T> find(ParseTree t, Class<?> node_type, PList<T> list) {
        if (t != null && t.getClass().equals(node_type)) {
            list.add((T) t);
            return list;
        }
        int n = t.getChildCount();
        for (int i = 0; i < n; i++) {
            find(t.getChild(i), node_type, list);
        }

        return list;
    }

}
