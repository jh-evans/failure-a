package org.lock.visitors;

import org.antlr.v4.runtime.tree.ParseTree;
import org.lock.TheClass;
import org.lock.antlr4.JavaParser;

public class QNC extends TheVisitor {
    public Class<?> target() {
        return JavaParser.QualifiedNameContext.class;
    }
    
    public void visit(ParseTree t, TheClass output) {
        JavaParser.QualifiedNameContext cuc = (JavaParser.QualifiedNameContext) t;
        System.out.println(cuc.getText());
    }
}