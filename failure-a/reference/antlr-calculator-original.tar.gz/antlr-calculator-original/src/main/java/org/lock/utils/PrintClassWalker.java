package org.lock.utils;

import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.lock.TheClass;
import org.lock.TypeChecker;
import org.lock.Walker;
import org.lock.antlr4.JavaLexer;
import org.lock.antlr4.JavaParser;

public class PrintClassWalker implements Walker {
    private int i;

    public PrintClassWalker() {
        this.i = 0;
    }

    private String spaces(int n) {
        if (n == 0) {
            return "";
        }
        return String.format("%" + n + "s", "");
    }

    public void walk(ParseTree t) {
        System.out.println(spaces(i) + t.getClass());

        int n = t.getChildCount();
        for (int j = 0; j < n; j++) {
            i = i + 4;
            walk(t.getChild(j));
            i = i - 4;
        }
    }

    public void walk(String filename) {
        try {
            JavaParser parser = new JavaParser(
                    new CommonTokenStream(new JavaLexer(CharStreams.fromString(FileUtils.getFile(filename)))));
            TypeChecker tc = new TypeChecker(new TheClass());
            tc.walk(parser.compilationUnit());

            parser = new JavaParser(new CommonTokenStream(new JavaLexer(CharStreams.fromString(FileUtils.getFile(filename)))));
            new PrintClassWalker().walk(parser.compilationUnit());
        } catch (java.io.IOException ioe) {
            System.err.println("Reading input file failed for <" + filename + ">");
            ioe.printStackTrace();
        }
    }
}