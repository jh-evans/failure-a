package org.lock;

import java.util.Iterator;
import java.util.function.Function;

import org.antlr.v4.runtime.tree.ParseTree;

public class ForEach<T> implements Iterable<T> {
    private int max;
    private Function<Integer, ParseTree> next;
    
    public ForEach(T t, int max, Function<Integer, ParseTree> next) {
        this.max = max;
        this.next = next;
    }
    
    @Override
    public Iterator<T> iterator() {
        return new GeneralIterator<T>(this.max, next);
    }
    
    private class GeneralIterator<T> implements Iterator<T> {
        private int i;
        private int max;
        private Function<Integer, ParseTree> next;
        
        public GeneralIterator(int max, Function<Integer, ParseTree> next) {
            this.i = 0;
            this.max = max;
            this.next = next;
        }
        
        @Override
        public boolean hasNext() {
            return i < max;
        }

        @Override
        public T next() {
            return (T) next.apply(i++);
        }
        
    }
}