package org.lock.visitors;

import org.antlr.v4.runtime.tree.ParseTree;
import org.lock.TheClass;
import org.lock.antlr4.JavaParser;
import org.lock.antlr4.JavaParser.ClassBodyDeclarationContext;
import org.lock.utils.PList;

public class CBC extends TheVisitor {
    public Class<?> target() {
        return JavaParser.ClassBodyContext.class;
    }
    
    public void visit(ParseTree t, TheClass output) {
        JavaParser.ClassBodyContext cbc = (JavaParser.ClassBodyContext) t;

        PList<JavaParser.ClassBodyDeclarationContext> decls = find(t, org.lock.antlr4.JavaParser.ClassBodyDeclarationContext.class);

        PList<ClassBodyDeclarationContext> publicdecls = decls.comp(d -> d.getChild(0).getText().equals("public"));
        
        for(ClassBodyDeclarationContext d : publicdecls) {
            output.addPublic(d.getText());
        }
    }
}
