package org.lock.utils;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class FileUtils {
    public static String oneline(List<String> strs) {
        String result = "";

        for (String line : strs) {
            result += line;
        }

        return result;
    }

    public static String getFile(String filename) throws java.io.IOException {
        return oneline(Files.readAllLines(Paths.get(filename)));
    }
}