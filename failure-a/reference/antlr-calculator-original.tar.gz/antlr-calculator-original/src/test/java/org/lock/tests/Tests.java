package org.lock.tests;

import static org.junit.Assert.assertTrue;

import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.junit.Test;
import org.lock.TheClass;
import org.lock.TypeChecker;
import org.lock.antlr4.JavaLexer;
import org.lock.antlr4.JavaParser;
import org.lock.antlr4.JavaParser.CompilationUnitContext;
import org.lock.utils.FileUtils;
import org.lock.utils.PrintClassWalker;

public class Tests {    
    @Test
    public void java_parse() {
        String filename = "JavaInputToParser.java";
        try {
            JavaParser parser = new JavaParser(new CommonTokenStream(new JavaLexer(CharStreams.fromString(FileUtils.getFile(filename)))));
            CompilationUnitContext root = parser.compilationUnit();
            
            TheClass output = new TheClass();
            TypeChecker tc = new TypeChecker(output);
            
            tc.walk(root);
            
            System.out.println(output);
            //new PrintClassWalker().walk(parser.compilationUnit());
            
            assertTrue(true);
        } catch(java.io.IOException ioe) {
            System.err.println("Reading input file failed for <" + filename + ">");
            ioe.printStackTrace();

            assertTrue(false);
        }
    }
}
