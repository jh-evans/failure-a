package org.lock;

public class Main {

	public static void main(String[] args) {
	}
}
