package org.lock;

import org.lock.antlr4.*;

// Based on: https://www.aldoraweb.com/antlr-quick-start-calculator-example/

public class CalculatorVisitor extends antlrCalculatorBaseVisitor<Void> {
    @Override
    public Void visitExpression(antlrCalculatorParser.ExpressionContext ctx) {
    	System.out.println("E:" + ctx.getText());
    	return null;
    	
    }
    
    @Override
    public Void visitAssignment(antlrCalculatorParser.AssignmentContext ctx) {
    	System.out.println("A: " + ctx.getText());
    	return null;
    	
    }

	@Override
	public Void visitType_def(antlrCalculatorParser.Type_defContext ctx) {
    	System.out.println("TD: " + ctx.getText());
    	return null;
	}
    
	@Override
	public Void visitProgram(antlrCalculatorParser.ProgramContext ctx) {
    	System.out.println("P: " + ctx.getText());
    	return null;
	}
}