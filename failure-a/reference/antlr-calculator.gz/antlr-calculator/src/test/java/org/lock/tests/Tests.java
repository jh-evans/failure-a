package org.lock.tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.junit.Test;
import org.lock.antlr4.antlrCalculatorLexer;
import org.lock.antlr4.antlrCalculatorParser;

import org.lock.CalculatorVisitor;

public class Tests {

   private void walk(ParseTree t) {
    	System.out.println(t.getClass() + " " + t.getText());
    	
        int n = t.getChildCount();
        for (int i = 0; i<n; i++) {
            walk(t.getChild(i));
        }
        
    } 
    
	/*
    public void walk_test() {
    	String expression = "6 + 4";
        CharStream charStream = CharStreams.fromString(expression);
        antlrCalculatorLexer lexer = new antlrCalculatorLexer(charStream);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        antlrCalculatorParser parser = new antlrCalculatorParser(tokens);
        CalculatorVisitor visitor = new CalculatorVisitor();
        Integer value = visitor.visit(parser.expr());
        assertEquals((Integer) 10, value);
    }
    
    bcd99 = []
    List<inferred type> bcd99 = new ArrayList<inferred type>(); 
*/
	
    @Test
    public void walk_empty_list() {
    	String expression = "type x_: bcd99 = []";
        CharStream charStream = CharStreams.fromString(expression);
        antlrCalculatorLexer lexer = new antlrCalculatorLexer(charStream);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        antlrCalculatorParser parser = new antlrCalculatorParser(tokens);
        CalculatorVisitor visitor = new CalculatorVisitor();
        //visitor.visit(parser.program()); // where we start in grammar (our root), given above expression
        walk(parser.program());
        assertTrue(true);
    }
}
